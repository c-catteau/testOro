UPGRADE to any 1.0.0-alpha and beta version
=======================

### General

  * Upgrade to 1.0.0-alpha or beta is not supported and full reinstall with drop database, clear cache folders is required
  